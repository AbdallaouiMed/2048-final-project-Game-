#include "datamodel.h"
#include <QColor>

DataModel::DataModel(QObject* parent)
{
    // creating matrix filled with 0 (by default int constructor)
    matrix.resize(4);
    for (int y = 0; y < matrix.size(); ++y)
        matrix[y].resize(4);

    // adding a first cell filled with a 2
    addInEmptyCell();
}

int DataModel::rowCount(const QModelIndex& parent) const
{
    // we return the matrix height
    return matrix.size();
}

int DataModel::columnCount(const QModelIndex& parent) const
{
    // we return the matrix width
    return matrix.size() > 0 ? matrix[0].size() : 0;
}

QVariant DataModel::data(const QModelIndex& index, int role) const
{
    // if the index is not valid, we stop here
    if (!index.isValid())
        return QVariant();

    // if the view is asking for the text to display
    if (role == Qt::DisplayRole)
    {
        // if the cell is valid
        if (index.row() < rowCount() && index.column() < columnCount())
        {
            // if the cell number is higher than 0 (which means "not empty")
            // we return its value otherwise we return an empty string (instead of 0)
            if (matrix[index.row()][index.column()] > 0)
                return matrix[index.row()][index.column()];
            else
                QString();
        }
        return QVariant();
    }

    // if the view is asking for the text alignment
    // we return AlignCenter for every cell
    if (role == Qt::TextAlignmentRole)
        return Qt::AlignCenter;

    // if the view is asking for the background color of the cell
    // we return colors based on the official 2048 game
    if (role == Qt::BackgroundRole)
    {
        switch (matrix[index.row()][index.column()])
        {
        case 0:
            return QColor("#ccc0b3");
        case 2:
            return QColor("#eee4da");
        case 4:
            return QColor("#ede0c8");
        case 8:
            return QColor("#f2b179");
        case 16:
            return QColor("#f59563");
        case 32:
            return QColor("#f67c5f");
        case 64:
            return QColor("#f65e3b");
        case 128:
            return QColor("#edcf72");
        case 256:
            return QColor("#edcc61");
        case 512:
            return QColor("#edc850");
        case 1024:
            return QColor("#edc53f");
        case 2048:
            return QColor("#edc22e");
        default:
            return QColor("#3e3933");
        }
    }

    // if the view is asking for the text color of the cell
    // we return colors based on the official 2048 game
    if (role == Qt::ForegroundRole)
    {
        switch (matrix[index.row()][index.column()])
        {
        case 2:
        case 4:
            return QColor("#776e65");
        default:
            return QColor("#f9f6f2");
        }
    }

    return QVariant();
}

QModelIndex DataModel::index(int row, int column, const QModelIndex& parent) const
{
    return createIndex(row, column);
}

QModelIndex DataModel::parent(const QModelIndex& index) const
{
    return QModelIndex();
}

void DataModel::left()
{
    QVector<QVector<int>> temp = matrix;

    // move left
    moveLeft();

    // nothing changed so we stop as the movement is "invalid"
    if (matrix == temp)
    {
        checkIfDead();
        return;
    }

    // emiting signal for the view to know that data changed
    emit dataChanged(index(0, 0), index(rowCount() - 1, columnCount() - 1));

    // adding a cell filled with a 2
    addInEmptyCell();
}

void DataModel::right()
{
    QVector<QVector<int>> temp = matrix;

    // move right
    moveRight();

    // nothing changed so we stop as the movement is "invalid"
    if (matrix == temp)
    {
        checkIfDead();
        return;
    }

    // emiting signal for the view to know that data changed
    emit dataChanged(index(0, 0), index(rowCount() - 1, columnCount() - 1));

    // adding a cell filled with a 2
    addInEmptyCell();
}

void DataModel::top()
{
    QVector<QVector<int>> temp = matrix;

    // transpose
    transpose();
    // move left
    moveLeft();
    // transpose
    transpose();

    // nothing changed so we stop as the movement is "invalid"
    if (matrix == temp)
    {
        checkIfDead();
        return;
    }

    // emiting signal for the view to know that data changed
    emit dataChanged(index(0, 0), index(rowCount() - 1, columnCount() - 1));

    // adding a cell filled with a 2
    addInEmptyCell();
}

void DataModel::bottom()
{
    QVector<QVector<int>> temp = matrix;

    // transpose
    transpose();
    // move right
    moveRight();
    // transpose
    transpose();

    // nothing changed so we stop as the movement is "invalid"
    if (matrix == temp)
    {
        checkIfDead();
        return;
    }

    // emiting signal for the view to know that data changed
    emit dataChanged(index(0, 0), index(rowCount() - 1, columnCount() - 1));

    // adding a cell filled with a 2
    addInEmptyCell();
}

int DataModel::getScore() const
{
    return this->score;
}

void DataModel::checkIfDead()
{
    bool lose = true;
    for (int y = 0; y < matrix.size(); ++y)
    {
        for (int x = 0; x < matrix[y].size(); ++x)
        {
            if (matrix[y][x] == 0)
                lose = false;

            if (y > 0)
            {
                // two vertical adjacent cells are equals
                // it means we can still play
                if (matrix[y - 1][x] == matrix[y][x])
                {
                    lose = false;
                }
            }

            if (x > 0)
            {
                // two horizontal adjacent cells are equals
                // it means we can still play
                if (matrix[y][x - 1] == matrix[y][x])
                {
                    lose = false;
                }
            }
        }
    }

    if (lose)
        emit lost();
}

void DataModel::addInEmptyCell()
{
    // checking which row has at least an empty cell
    QVector<int> emptyRows;
    for (int y = 0; y < matrix.size(); ++y)
    {
        for (int x = 0; x < matrix[y].size(); ++x)
        {
            if (matrix[y][x] == 0)
            {
                emptyRows.append(y);
                break;
            }
        }
    }

    // if no row has an empty cell, it means that the game has ended
    if (emptyRows.size() == 0)
    {
        // we emit a signal to tell that the game has ended
        emit lost();
        return;
    }

    // we chose a random row
    int y = emptyRows[qrand() % emptyRows.size()];

    // we add indexes of the chosen row which are empty cells
    QVector<int> emptyCols;
    for (int x = 0; x < matrix[y].size(); ++x)
        if (matrix[y][x] == 0)
            emptyCols.append(x);

    // we chose a random column
    int x = emptyCols[qrand() % emptyCols.size()];

    // we set it to 2 or 4 (2 * (1 OR 2))
    matrix[y][x] = 2 * (1 + qrand() % 2);

    // emiting signal for the view to know that data changed
    emit dataChanged(index(0, 0), index(rowCount() - 1, columnCount() - 1));
}

void DataModel::transpose()
{
    // creating a temp matrix
    QVector<QVector<int>> temp;
    temp.resize(4);
    for (int y = 0; y < temp.size(); ++y)
        temp[y].resize(4);

    // transposing the matrix
    for (int y = 0; y < temp.size(); ++y)
        for (int x = 0; x < temp[y].size(); ++x)
            temp[x][y] = matrix[y][x];

    matrix = temp;
}

void DataModel::moveLeft()
{
    // removing all empty cell in each row
    for (int y = 0; y < matrix.size(); ++y)
        matrix[y].removeAll({0});

    // merge
    for (int y = 0; y < matrix.size(); ++y)
    {
        for (int x = 0; x < matrix[y].size() - 1; ++x)
        {
            // if the cell is the same as the next one (without the empty cells removed previously)
            if (matrix[y][x] == matrix[y][x + 1])
            {
                // we merge both cells into the current one
                matrix[y][x] = matrix[y][x] + matrix[y][x + 1];
                // adding sum to score
                score += matrix[y][x];
                // we set the next one to 0
                matrix[y][x + 1] = 0;
                // we skip the next one
                ++x;
            }
            else
            {
                matrix[y][x] = matrix[y][x];
            }
        }
    }

    for (int y = 0; y < matrix.size(); ++y)
    {
        // removing all empty cell in each row
        matrix[y].removeAll({0});
        // appending empty cells to fill the matrix
        for (int i = matrix[y].size(); i < 4; ++i)
            matrix[y].append(0);
    }
}

void DataModel::moveRight()
{
    // removing all empty cell in each row
    for (int y = 0; y < matrix.size(); ++y)
        matrix[y].removeAll({0});

    // merge
    for (int y = 0; y < matrix.size(); ++y)
    {
        for (int x = matrix[y].size() - 1; x > 0; --x)
        {
            // if the cell is the same as the previous one (without the empty cells removed previously)
            if (matrix[y][x] == matrix[y][x - 1])
            {
                // we merge both cells into the current one
                matrix[y][x] = matrix[y][x] + matrix[y][x - 1];
                // adding sum to score
                score += matrix[y][x];
                // we set the previous one to 0
                matrix[y][x - 1] = 0;
                // we skip the previous one
                --x;
            }
            else
            {
                matrix[y][x] = matrix[y][x];
            }
        }
    }

    for (int y = 0; y < matrix.size(); ++y)
    {
        // removing all empty cell in each row
        matrix[y].removeAll({0});
        // prepending empty cells to fill the matrix
        for (int i = matrix[y].size(); i < 4; ++i)
            matrix[y].prepend(0);
    }
}
