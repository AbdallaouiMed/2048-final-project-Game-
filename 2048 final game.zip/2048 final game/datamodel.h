#ifndef DATAMODEL_H
#define DATAMODEL_H

#include <QAbstractItemModel>

class DataModel : public QAbstractItemModel
{
    Q_OBJECT

public:
    DataModel(QObject* parent = nullptr);

    virtual int         rowCount(const QModelIndex& parent = QModelIndex()) const override;
    virtual int         columnCount(const QModelIndex& parent = QModelIndex()) const override;
    virtual QVariant    data(const QModelIndex& index, int role = Qt::DisplayRole) const override;
    virtual QModelIndex index(int row, int column, const QModelIndex& parent = QModelIndex()) const override;
    virtual QModelIndex parent(const QModelIndex& index) const override;

    void left();
    void right();
    void top();
    void bottom();
    int  getScore() const;

signals:
    void lost();

private:
    void checkIfDead();
    void addInEmptyCell();
    void transpose();
    void moveLeft();
    void moveRight();

    QVector<QVector<int>> matrix;
    int score = 0;
};




#endif // DATAMODEL_H
