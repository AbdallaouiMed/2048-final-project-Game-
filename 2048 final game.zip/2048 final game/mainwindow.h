#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWidget>
#include <QTableView>
#include "datamodel.h"
#include <QLabel>
#include <QProgressBar>
class MainWindow : public QWidget
{
    Q_OBJECT

public:
    MainWindow(QWidget* parent = nullptr);
    ~MainWindow();

    void lose();

private:
    QTableView* tableview;
    DataModel*  model;
    QLabel *MyScore;
    QProgressBar *MyProgressBar;
};
#endif // MAINWINDOW_H
