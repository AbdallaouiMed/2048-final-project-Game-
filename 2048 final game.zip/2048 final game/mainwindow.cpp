#include "mainwindow.h"
#include "datamodel.h"
#include <QGridLayout>
#include <QHeaderView>
#include <QPushButton>
#include <QMessageBox>
#include <QApplication>
#include <QStatusBar>
#include <QLabel>
#include<QToolBar>

MainWindow::MainWindow(QWidget* parent)
    : QWidget(parent)
{
    setFixedSize(400, 400);

    QGridLayout* layout = new QGridLayout;
    tableview = new QTableView;
    // setting all rows and columns to the same size
    tableview->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    tableview->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    // hiding headers
    tableview->horizontalHeader()->hide();
    tableview->verticalHeader()->hide();
    layout->addWidget(tableview, 1, 1);
    // 2048 data model
    model = new DataModel;
    tableview->setModel(model);
    // connecting failed signal to lose slot
    connect(model, &DataModel::lost, this, &MainWindow::lose);

    QPushButton* leftButton = new QPushButton("L");
    leftButton->setFixedSize(40, 40);
    leftButton->setShortcut(QKeySequence(Qt::Key_Left));
    layout->addWidget(leftButton, 1, 0, Qt::AlignCenter);

    QPushButton* rightButton = new QPushButton("R");
    rightButton->setFixedSize(40, 40);
    rightButton->setShortcut(QKeySequence(Qt::Key_Right));
    layout->addWidget(rightButton, 1, 2, Qt::AlignCenter);

    QPushButton* topButton = new QPushButton("T");
    topButton->setFixedSize(40, 40);
    topButton->setShortcut(QKeySequence(Qt::Key_Up));
    layout->addWidget(topButton, 0, 1, Qt::AlignCenter);

    QPushButton* bottomButton = new QPushButton("B");
    bottomButton->setFixedSize(40, 40);
    bottomButton->setShortcut(QKeySequence(Qt::Key_Down));
    layout->addWidget(bottomButton, 2, 1, Qt::AlignCenter);



    // connecting buttons to their respective movements
    connect(leftButton,   &QPushButton::clicked, model, &DataModel::left);
    connect(rightButton,  &QPushButton::clicked, model, &DataModel::right);
    connect(topButton,    &QPushButton::clicked, model, &DataModel::top);
    connect(bottomButton, &QPushButton::clicked, model, &DataModel::bottom);

   this->setLayout(layout);
}

MainWindow::~MainWindow()
{

}

void MainWindow::lose()
{
    QMessageBox::warning(this, "End of game", "Score: " + QString::number(model->getScore()));
    qApp->quit();
}
