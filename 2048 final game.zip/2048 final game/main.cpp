#include "mainwindow.h"

#include <QApplication>
#include <QDateTime>

int main(int argc, char* argv[])
{
    QApplication a(argc, argv);
    // setting Qt randomization with a seed based on time
    // (in order to have a different random each time we launch the app)
    qsrand(QDateTime::currentDateTimeUtc().toTime_t());
    MainWindow w;
    w.show();
    return a.exec();
}
